public class Foo {
  static int   a;
  static int[] b;   // array is not static, so skip for now
  
  public void foo () {
    a = 0;
  }
}